
import React, { useState, useEffect, useRef } from 'react';
import { Member, Supplement, PaymentStatus, Gender, MembershipPlan } from '../types';
import { formatCurrency, formatDate, calculateEndDate, fileToBase64 } from '../utils/helpers';
import { UserIcon } from './Icons';

interface MemberDetailModalProps {
    member: Member;
    supplements: Supplement[];
    onClose: () => void;
    onUpdate: (member: Member) => void;
    onDelete: (memberId: string) => void;
    onTakePhoto: () => void;
}

export const MemberDetailModal: React.FC<MemberDetailModalProps> = ({ member, supplements, onClose, onUpdate, onDelete, onTakePhoto }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState<Member>(member);
    const [showConfirmDelete, setShowConfirmDelete] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        setFormData(member);
    }, [member]);
    
    useEffect(() => {
        const newEndDate = calculateEndDate(formData.startDate, formData.membershipPlan);
        setFormData(prev => ({...prev, endDate: newEndDate}));
    }, [formData.startDate, formData.membershipPlan]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => {
            let updatedState = { ...prev, [name]: value };
             if (name === 'paymentStatus') {
                if (value === PaymentStatus.Paid) updatedState.amountPaid = updatedState.gymFees;
                else if (value === PaymentStatus.NotPaid) updatedState.amountPaid = 0;
            }
            if (name === 'gymFees' && updatedState.paymentStatus === PaymentStatus.Paid) {
                updatedState.amountPaid = parseFloat(value);
            }
            updatedState.dueAmount = (Number(updatedState.gymFees) || 0) - (Number(updatedState.amountPaid) || 0);
            return updatedState;
        });
    };

    const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const base64 = await fileToBase64(e.target.files[0]);
            onUpdate({ ...member, photo: base64 });
        }
    };
    
    const handleUpdate = () => {
        onUpdate(formData);
        setIsEditing(false);
    };

    const getStatus = (endDate: string) => {
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        const diffDays = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays < 0) return { label: 'Expired', color: 'text-red-400' };
        if (diffDays <= 7) return { label: `Expiring in ${diffDays} days`, color: 'text-amber-400' };
        return { label: 'Active', color: 'text-green-400' };
    };
    
    const status = getStatus(member.endDate);
    
    const DetailItem: React.FC<{label:string, value: React.ReactNode}> = ({label, value}) => (
        <div>
            <p className="text-xs text-sky-300 uppercase">{label}</p>
            <p className="text-white font-semibold">{value}</p>
        </div>
    );

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-slate-800/80 border border-cyan-500/20 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-8 shadow-2xl shadow-cyan-900/50 relative" onClick={e => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">&times;</button>
                
                {showConfirmDelete ? (
                     <div className="text-center p-8">
                        <h3 className="text-2xl font-bold text-red-500 mb-4">Confirm Deletion</h3>
                        <p>Are you sure you want to delete {member.fullName}? This action cannot be undone.</p>
                        <div className="mt-6 flex justify-center gap-4">
                            <button onClick={() => onDelete(member.id)} className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-6 rounded-lg">Delete</button>
                            <button onClick={() => setShowConfirmDelete(false)} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg">Cancel</button>
                        </div>
                    </div>
                ) : isEditing ? (
                    // Edit Form
                    <div>
                        <h2 className="text-2xl font-orbitron mb-6 text-cyan-400">Editing {member.fullName}</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <InputField label="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} required />
                            <InputField label="Age" name="age" type="number" value={formData.age} onChange={handleChange} required />
                            <SelectField label="Gender" name="gender" value={formData.gender} onChange={handleChange} options={Object.values(Gender)} required />
                            <InputField label="Contact Number" name="contactNumber" value={formData.contactNumber || ''} onChange={handleChange} />
                            <SelectField label="Membership Plan" name="membershipPlan" value={formData.membershipPlan} onChange={handleChange} options={Object.values(MembershipPlan)} required />
                            <InputField label="Start Date" name="startDate" type="date" value={formData.startDate} onChange={handleChange} required />
                            <InputField label="End Date" name="endDate" type="date" value={formData.endDate} readOnly />
                            <InputField label="Gym Fee Amount" name="gymFees" type="number" step="0.01" value={formData.gymFees} onChange={handleChange} required />
                            <SelectField label="Payment Status" name="paymentStatus" value={formData.paymentStatus} onChange={handleChange} options={Object.values(PaymentStatus)} required />
                             {formData.paymentStatus === PaymentStatus.Partial && <InputField label="Amount Paid" name="amountPaid" type="number" step="0.01" value={formData.amountPaid} onChange={(e) => setFormData(p => ({...p, amountPaid: parseFloat(e.target.value)}))} required />}
                             {(formData.paymentStatus === PaymentStatus.Partial || formData.paymentStatus === PaymentStatus.NotPaid) && <InputField label="Expected Payment Date" name="expectedPaymentDate" type="date" value={formData.expectedPaymentDate || ''} onChange={handleChange} />}
                            <InputField label="Due Amount" name="dueAmount" type="number" value={formData.dueAmount.toFixed(2)} readOnly />
                            <div className="md:col-span-3"><TextAreaField label="Remarks" name="remarks" value={formData.remarks} onChange={handleChange} /></div>
                        </div>
                        <div className="mt-6 flex justify-end gap-4">
                            <button onClick={() => setIsEditing(false)} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg">Cancel</button>
                            <button onClick={handleUpdate} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-6 rounded-lg">Save Changes</button>
                        </div>
                    </div>
                ) : (
                    // Detail View
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-1 flex flex-col items-center">
                            <div className="w-48 h-48 rounded-full border-2 border-cyan-500/50 flex items-center justify-center bg-slate-900/50 overflow-hidden relative group">
                                {member.photo ? <img src={member.photo} alt={member.fullName} className="w-full h-full object-cover" /> : <UserIcon className="w-24 h-24 text-cyan-500/30" />}
                                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handlePhotoUpload} className="hidden" />
                                    <button onClick={() => fileInputRef.current?.click()} className="text-xs bg-sky-600 hover:bg-sky-500 text-white font-bold py-1 px-3 rounded-md transition-colors mb-2">Upload</button>
                                    <button onClick={onTakePhoto} className="text-xs bg-purple-600 hover:bg-purple-500 text-white font-bold py-1 px-3 rounded-md transition-colors">Camera</button>
                                    {member.photo && (
                                        <button 
                                            onClick={() => onUpdate({ ...member, photo: null })} 
                                            className="text-xs bg-red-600 hover:bg-red-500 text-white font-bold py-1 px-3 rounded-md transition-colors mt-2"
                                        >
                                            Remove
                                        </button>
                                    )}
                                </div>
                            </div>
                            <h2 className="text-3xl font-orbitron font-bold text-white mt-4 text-center">{member.fullName}</h2>
                            <p className="text-sky-300">{member.id}</p>
                            <div className="mt-6 flex gap-2">
                                <button onClick={() => setIsEditing(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-6 rounded-lg">Edit</button>
                                <button onClick={() => setShowConfirmDelete(true)} className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-6 rounded-lg">Delete</button>
                            </div>
                        </div>
                        <div className="lg:col-span-2 space-y-6">
                            <div>
                                <h3 className="font-orbitron text-lg text-cyan-400 border-b border-cyan-500/20 pb-2 mb-3">Membership Details</h3>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                    <DetailItem label="Status" value={<span className={status.color}>{status.label}</span>} />
                                    <DetailItem label="Plan" value={member.membershipPlan} />
                                    <DetailItem label="Expires On" value={formatDate(member.endDate)} />
                                    <DetailItem label="Gym Fees" value={formatCurrency(member.gymFees)} />
                                    <DetailItem label="Amount Paid" value={formatCurrency(member.amountPaid)} />
                                    <DetailItem label="Dues" value={<span className={member.dueAmount > 0 ? "text-amber-400" : "text-green-400"}>{formatCurrency(member.dueAmount)}</span>} />
                                </div>
                            </div>
                             <div>
                                <h3 className="font-orbitron text-lg text-cyan-400 border-b border-cyan-500/20 pb-2 mb-3">Supplements</h3>
                                {supplements.length > 0 ? (
                                    <div className="space-y-2 text-sm">
                                    {supplements.map(s => <div key={s.id} className="flex justify-between items-center bg-slate-700/50 p-2 rounded"><span>{formatDate(s.purchaseDate)}</span><span>{formatCurrency(s.supplementAmount)}</span><span className={s.dueAmount > 0 ? 'text-amber-400' : 'text-green-400'}>{s.paymentStatus}</span></div>)}
                                    </div>
                                ) : <p className="text-gray-400">No supplement purchases.</p>}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};


// Field components for edit form
const InputField: React.FC<any> = ({ label, name, ...props }) => (
    <div>
        <label className="block text-xs font-medium text-sky-200 mb-1">{label}</label>
        <input name={name} {...props} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500" />
    </div>
);
const SelectField: React.FC<any> = ({ label, name, options, ...props }) => (
    <div>
        <label className="block text-xs font-medium text-sky-200 mb-1">{label}</label>
        <select name={name} {...props} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500">
            <option value="">Select...</option>
            {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    </div>
);
const TextAreaField: React.FC<any> = ({ label, name, ...props }) => (
    <div>
        <label className="block text-xs font-medium text-sky-200 mb-1">{label}</label>
        <textarea name={name} {...props} rows={3} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500" />
    </div>
);