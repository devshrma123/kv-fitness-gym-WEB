
import React, { useState, useMemo } from 'react';
import { Member, MembershipPlan } from '../types';
import { formatDate } from '../utils/helpers';
import { UserIcon } from './Icons';

interface MembersProps {
  members: Member[];
  onSelectMember: (member: Member) => void;
}

export const Members: React.FC<MembersProps> = ({ members, onSelectMember }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [planFilter, setPlanFilter] = useState<MembershipPlan | ''>('');

  const filteredMembers = useMemo(() => {
    return members
      .filter(member => {
        const matchesSearch =
          member.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (member.contactNumber || '').includes(searchTerm);
        const matchesPlan = !planFilter || member.membershipPlan === planFilter;
        return matchesSearch && matchesPlan;
      })
      .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime());
  }, [members, searchTerm, planFilter]);

  const getStatus = (endDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    const diffTime = end.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return { label: 'Expired', className: 'bg-red-500/20 text-red-400 border-red-500/30', borderClass: 'border-l-4 border-red-500' };
    if (diffDays <= 7) return { label: 'Expiring Soon', className: 'bg-amber-500/20 text-amber-400 border-amber-500/30', borderClass: 'border-l-4 border-amber-500' };
    return { label: 'Active', className: 'bg-green-500/20 text-green-400 border-green-500/30', borderClass: 'border-l-4 border-green-500' };
  };

  return (
    <div className="bg-slate-800/50 border border-cyan-500/20 p-6 md:p-8 rounded-2xl backdrop-blur-sm">
        <h2 className="text-3xl font-orbitron font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-white">Gym Members</h2>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
            <input
                type="text"
                placeholder="Search by name or contact..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="flex-grow bg-slate-900/70 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all"
            />
            <select
                value={planFilter}
                onChange={e => setPlanFilter(e.target.value as MembershipPlan | '')}
                className="bg-slate-900/70 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all"
            >
                <option value="">All Plans</option>
                {Object.values(MembershipPlan).map(plan => (
                    <option key={plan} value={plan}>{plan}</option>
                ))}
            </select>
        </div>

        <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
            {filteredMembers.length > 0 ? (
                filteredMembers.map(member => {
                    const status = getStatus(member.endDate);
                    return (
                        <div
                            key={member.id}
                            onClick={() => onSelectMember(member)}
                            className={`flex items-center p-4 rounded-lg cursor-pointer transition-all duration-200 bg-slate-800 hover:bg-slate-700/70 ${status.borderClass}`}
                        >
                            <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-700 mr-4 flex-shrink-0">
                                {member.photo ? (
                                    <img src={member.photo} alt={member.fullName} className="w-full h-full object-cover" />
                                ) : (
                                    <UserIcon className="w-full h-full text-slate-500 p-2" />
                                )}
                            </div>
                            <div className="flex-grow">
                                <p className="font-bold text-white text-lg">{member.fullName}</p>
                                <p className="text-sm text-sky-300">{member.id} &bull; {member.membershipPlan}</p>
                            </div>
                            <div className="text-right ml-4 flex-shrink-0">
                                <p className="text-sm text-gray-300">Expires: {formatDate(member.endDate)}</p>
                                <span className={`mt-1 inline-block text-xs font-semibold px-3 py-1 rounded-full ${status.className}`}>{status.label}</span>
                            </div>
                        </div>
                    );
                })
            ) : (
                <div className="text-center py-12 text-gray-400">
                    <p className="text-lg">No members found.</p>
                    <p className="text-sm">Try adjusting your search or filters.</p>
                </div>
            )}
        </div>
    </div>
  );
};