
import React, { useState, useMemo } from 'react';
import { Member, Supplement, ReportStats } from '../types';
import { formatCurrency } from '../utils/helpers';

interface ReportsProps {
  members: Member[];
  supplements: Supplement[];
}

export const Reports: React.FC<ReportsProps> = ({ members, supplements }) => {
  const [reportMonth, setReportMonth] = useState(new Date().toISOString().slice(0, 7));
  const [stats, setStats] = useState<ReportStats | null>(null);

  const generateReport = () => {
    const [year, month] = reportMonth.split('-');
    
    const newMembers = members.filter(m => m.registrationDate.startsWith(reportMonth));
    
    const activeMembers = members.filter(member => {
      const startDate = new Date(member.startDate);
      const endDate = new Date(member.endDate);
      const monthStart = new Date(parseInt(year), parseInt(month) - 1, 1);
      const monthEnd = new Date(parseInt(year), parseInt(month), 0);
      return startDate <= monthEnd && endDate >= monthStart;
    });

    const expiredMembers = members.filter(member => {
        const endDate = new Date(member.endDate);
        return endDate.getFullYear() === parseInt(year) && (endDate.getMonth() + 1) === parseInt(month);
    });

    const monthlyGymCollected = newMembers.reduce((sum, member) => sum + member.amountPaid, 0);
    const monthlyGymDue = newMembers.reduce((sum, member) => sum + member.dueAmount, 0);

    const monthlySupplements = supplements.filter(s => s.purchaseDate.startsWith(reportMonth));
    const supplementSales = monthlySupplements.reduce((sum, s) => sum + s.amountPaid, 0);
    const supplementDue = monthlySupplements.reduce((sum, s) => sum + s.dueAmount, 0);

    setStats({
      newMembers: newMembers.length,
      activeMembers: activeMembers.length,
      expiredMembers: expiredMembers.length,
      gymCollected: monthlyGymCollected,
      gymDue: monthlyGymDue,
      supplementSales: supplementSales,
      supplementDue: supplementDue,
      supplementsSold: monthlySupplements.length,
    });
  };
  
  // Auto-generate report on first load for the current month
  useState(() => {
    generateReport();
  });
  
  const handleGenerateClick = () => {
      generateReport();
  };

  return (
    <div className="bg-slate-800/50 border border-cyan-500/20 p-6 md:p-8 rounded-2xl backdrop-blur-sm">
      <h2 className="text-3xl font-orbitron font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-white">Reports & Analytics</h2>
      
      <div className="flex flex-col md:flex-row gap-4 justify-center items-center mb-8">
        <input
          type="month"
          value={reportMonth}
          onChange={e => setReportMonth(e.target.value)}
          className="bg-slate-900/70 border border-slate-600 rounded-md py-2 px-4 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all"
        />
        <button
          onClick={handleGenerateClick}
          className="w-full md:w-auto font-orbitron bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-bold py-2 px-8 rounded-lg uppercase tracking-wider transition-all duration-300 transform hover:scale-105"
        >
          Generate Report
        </button>
      </div>
      
      {stats ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <ReportCard label="New Members" value={stats.newMembers} />
          <ReportCard label="Active Members (Month)" value={stats.activeMembers} />
          <ReportCard label="Expired Members (Month)" value={stats.expiredMembers} />
          <ReportCard label="Supplements Sold" value={stats.supplementsSold} />
          <ReportCard label="Gym Fees Collected" value={formatCurrency(stats.gymCollected)} />
          <ReportCard label="Gym Fees Due" value={formatCurrency(stats.gymDue)} />
          <ReportCard label="Supplement Sales" value={formatCurrency(stats.supplementSales)} />
          <ReportCard label="Supplement Dues" value={formatCurrency(stats.supplementDue)} />
        </div>
      ) : (
        <p className="text-center text-gray-400 py-8">Select a month and generate a report to see analytics.</p>
      )}
    </div>
  );
};

const ReportCard: React.FC<{ label: string, value: string | number }> = ({ label, value }) => (
    <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700 text-center">
        <p className="text-sm text-sky-300 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-orbitron font-bold text-white mt-1">{value}</p>
    </div>
);
