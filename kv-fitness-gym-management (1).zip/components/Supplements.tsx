
import React, { useState } from 'react';
import { Member, Supplement, PaymentStatus } from '../types';

interface SupplementsProps {
    members: Member[];
    supplements: Supplement[];
    onAddSupplement: (supplementData: Omit<Supplement, 'id' | 'createdDate' | 'dueAmount' | 'memberName'>) => void;
}

export const Supplements: React.FC<SupplementsProps> = ({ members, onAddSupplement }) => {
    const initialFormState = {
        memberId: '',
        purchaseDate: new Date().toISOString().split('T')[0],
        supplementAmount: '',
        paymentStatus: '' as PaymentStatus,
        amountPaid: '',
        expectedPaymentDate: '',
        remarks: ''
    };
    const [formData, setFormData] = useState(initialFormState);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => {
            let updatedState = { ...prev, [name]: value };
            if (name === 'paymentStatus') {
                if (value === PaymentStatus.Paid) updatedState.amountPaid = updatedState.supplementAmount;
                else if (value === PaymentStatus.NotPaid) updatedState.amountPaid = '0';
            }
            if (name === 'supplementAmount' && updatedState.paymentStatus === PaymentStatus.Paid) {
                updatedState.amountPaid = value;
            }
            return updatedState;
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const supplementAmount = parseFloat(formData.supplementAmount) || 0;
        let amountPaid = 0;
        if (formData.paymentStatus === PaymentStatus.Paid) amountPaid = supplementAmount;
        else if (formData.paymentStatus === PaymentStatus.Partial) amountPaid = parseFloat(formData.amountPaid) || 0;
        
        onAddSupplement({
            ...formData,
            supplementAmount,
            amountPaid,
            expectedPaymentDate: formData.expectedPaymentDate || null,
        });
        setFormData(initialFormState);
    };

    const dueAmount = (parseFloat(formData.supplementAmount) || 0) - (parseFloat(formData.amountPaid) || 0);

    return (
        <div className="bg-slate-800/50 border border-cyan-500/20 p-6 md:p-8 rounded-2xl backdrop-blur-sm">
            <h2 className="text-3xl font-orbitron font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-white">Supplement Management</h2>
            <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <SelectField label="Select Member" name="memberId" value={formData.memberId} onChange={handleChange} required>
                        <option value="">Select a member</option>
                        {members.map(m => <option key={m.id} value={m.id}>{m.fullName} ({m.id})</option>)}
                    </SelectField>
                    <InputField label="Purchase Date" name="purchaseDate" type="date" value={formData.purchaseDate} onChange={handleChange} required />
                    <InputField label="Supplement Amount" name="supplementAmount" type="number" step="0.01" value={formData.supplementAmount} onChange={handleChange} required />
                    <SelectField label="Payment Status" name="paymentStatus" value={formData.paymentStatus} onChange={handleChange} required>
                        <option value="">Select status</option>
                        {Object.values(PaymentStatus).map(s => <option key={s} value={s}>{s}</option>)}
                    </SelectField>
                    
                    {formData.paymentStatus === PaymentStatus.Partial &&
                        <InputField label="Amount Paid" name="amountPaid" type="number" step="0.01" value={formData.amountPaid} onChange={handleChange} required />
                    }
                    {(formData.paymentStatus === PaymentStatus.Partial || formData.paymentStatus === PaymentStatus.NotPaid) &&
                        <InputField label="Expected Payment Date" name="expectedPaymentDate" type="date" value={formData.expectedPaymentDate} onChange={handleChange} />
                    }
                    <InputField label="Due Amount" name="dueAmount" type="number" value={dueAmount.toFixed(2)} readOnly />
                    
                    <div className="md:col-span-2 lg:col-span-3">
                        <TextAreaField label="Remarks" name="remarks" value={formData.remarks} onChange={handleChange} />
                    </div>
                </div>
                <div className="mt-8 text-center">
                    <button type="submit" className="w-full md:w-auto font-orbitron bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-bold py-3 px-12 rounded-lg text-lg uppercase tracking-wider transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/40">
                        Add Supplement Record
                    </button>
                </div>
            </form>
        </div>
    );
};


// Shared field components to reduce repetition
const InputField: React.FC<any> = ({ label, name, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-sky-200 mb-1">{label}{props.required && '*'}</label>
        <input id={name} name={name} {...props} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all" />
    </div>
);
const SelectField: React.FC<any> = ({ label, name, children, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-sky-200 mb-1">{label}{props.required && '*'}</label>
        <select id={name} name={name} {...props} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all">
            {children}
        </select>
    </div>
);
const TextAreaField: React.FC<any> = ({ label, name, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-sky-200 mb-1">{label}</label>
        <textarea id={name} name={name} {...props} rows={3} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all" />
    </div>
);
