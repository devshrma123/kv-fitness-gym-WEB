import React, { useState, useEffect, useRef } from 'react';
import { Member, PaymentStatus, Gender, MembershipPlan } from '../types';
import { calculateEndDate, fileToBase64 } from '../utils/helpers';
import { UserIcon } from './Icons';

interface RegistrationProps {
  onRegister: (memberData: Omit<Member, 'id' | 'registrationDate' | 'dueAmount'>) => void;
  openCamera: () => void;
  tempPhoto: string | null;
  setTempPhoto: React.Dispatch<React.SetStateAction<string | null>>;
}

export const Registration: React.FC<RegistrationProps> = ({ onRegister, openCamera, tempPhoto, setTempPhoto }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    age: '',
    gender: '' as Gender,
    contactNumber: '',
    membershipPlan: '' as MembershipPlan,
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    gymFees: '',
    paymentStatus: '' as PaymentStatus,
    amountPaid: '',
    expectedPaymentDate: '',
    remarks: '',
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const newEndDate = calculateEndDate(formData.startDate, formData.membershipPlan);
    setFormData(prev => ({ ...prev, endDate: newEndDate }));
  }, [formData.startDate, formData.membershipPlan]);
  
  useEffect(() => {
    // Clear temp photo on component mount
    setTempPhoto(null);
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
        let updatedState = { ...prev, [name]: value };
        
        if (name === 'paymentStatus') {
            if (value === PaymentStatus.Paid) {
                updatedState.amountPaid = updatedState.gymFees;
                updatedState.expectedPaymentDate = '';
            } else if (value === PaymentStatus.NotPaid) {
                updatedState.amountPaid = '0';
            }
        }
        
        if(name === 'gymFees' && updatedState.paymentStatus === PaymentStatus.Paid){
             updatedState.amountPaid = value;
        }

        return updatedState;
    });
  };
  
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const base64 = await fileToBase64(e.target.files[0]);
      setTempPhoto(base64);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const gymFees = parseFloat(formData.gymFees) || 0;
    let amountPaid = 0;
    if (formData.paymentStatus === PaymentStatus.Paid) {
        amountPaid = gymFees;
    } else if (formData.paymentStatus === PaymentStatus.Partial) {
        amountPaid = parseFloat(formData.amountPaid) || 0;
    }

    onRegister({
      ...formData,
      age: parseInt(formData.age),
      gymFees,
      amountPaid,
      expectedPaymentDate: formData.expectedPaymentDate || null,
      photo: tempPhoto,
    });

    // Reset form
    setFormData({
        fullName: '', age: '', gender: '' as Gender, contactNumber: '', membershipPlan: '' as MembershipPlan,
        startDate: new Date().toISOString().split('T')[0], endDate: '', gymFees: '',
        paymentStatus: '' as PaymentStatus, amountPaid: '', expectedPaymentDate: '', remarks: '',
    });
    setTempPhoto(null);
  };
  
  const dueAmount = (parseFloat(formData.gymFees) || 0) - (parseFloat(formData.amountPaid) || 0);

  return (
    <div className="bg-slate-800/50 border border-cyan-500/20 p-6 md:p-8 rounded-2xl backdrop-blur-sm">
      <h2 className="text-3xl font-orbitron font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-white">New Member Registration</h2>
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 flex flex-col items-center gap-4">
                 <div className="w-48 h-48 rounded-full border-2 border-dashed border-cyan-500/50 flex items-center justify-center bg-slate-900/50 overflow-hidden">
                    {tempPhoto ? (
                        <img src={tempPhoto} alt="Member preview" className="w-full h-full object-cover" />
                    ) : (
                        <UserIcon className="w-24 h-24 text-cyan-500/30" />
                    )}
                </div>
                <div className="flex gap-2">
                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handlePhotoUpload} className="hidden" />
                    <button type="button" onClick={() => fileInputRef.current?.click()} className="text-xs bg-sky-600 hover:bg-sky-500 text-white font-bold py-2 px-3 rounded-md transition-colors">Upload</button>
                    <button type="button" onClick={openCamera} className="text-xs bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-3 rounded-md transition-colors">Camera</button>
                    {tempPhoto && <button type="button" onClick={() => setTempPhoto(null)} className="text-xs bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-3 rounded-md transition-colors">Remove</button>}
                </div>
            </div>
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                 {/* Form fields */}
                <InputField label="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} required />
                <InputField label="Age" name="age" type="number" value={formData.age} onChange={handleChange} required />
                <SelectField label="Gender" name="gender" value={formData.gender} onChange={handleChange} options={Object.values(Gender)} required />
                <InputField label="Contact Number" name="contactNumber" value={formData.contactNumber} onChange={handleChange} />
                <SelectField label="Membership Plan" name="membershipPlan" value={formData.membershipPlan} onChange={handleChange} options={Object.values(MembershipPlan)} required />
                <InputField label="Start Date" name="startDate" type="date" value={formData.startDate} onChange={handleChange} required />
                <InputField label="End Date" name="endDate" type="date" value={formData.endDate} readOnly />
                <InputField label="Gym Fee Amount" name="gymFees" type="number" step="0.01" value={formData.gymFees} onChange={handleChange} required />
                <SelectField label="Payment Status" name="paymentStatus" value={formData.paymentStatus} onChange={handleChange} options={Object.values(PaymentStatus)} required />
                
                {(formData.paymentStatus === PaymentStatus.Partial) && (
                    <InputField label="Amount Paid" name="amountPaid" type="number" step="0.01" value={formData.amountPaid} onChange={handleChange} required />
                )}
                {(formData.paymentStatus === PaymentStatus.Partial || formData.paymentStatus === PaymentStatus.NotPaid) && (
                     <InputField label="Expected Payment Date" name="expectedPaymentDate" type="date" value={formData.expectedPaymentDate} onChange={handleChange} />
                )}
                 <InputField label="Due Amount" name="dueAmount" type="number" value={dueAmount.toFixed(2)} readOnly />
                <div className="md:col-span-2">
                    <TextAreaField label="Remarks" name="remarks" value={formData.remarks} onChange={handleChange} />
                </div>
            </div>
        </div>

        <div className="mt-8 text-center">
          <button type="submit" className="w-full md:w-auto font-orbitron bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-bold py-3 px-12 rounded-lg text-lg uppercase tracking-wider transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/40">
            Register Member
          </button>
        </div>
      </form>
    </div>
  );
};

// Sub-components for form fields
const InputField: React.FC<any> = ({ label, name, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-sky-200 mb-1">{label}{props.required && '*'}</label>
        <input id={name} name={name} {...props} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all" />
    </div>
);
const SelectField: React.FC<any> = ({ label, name, options, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-sky-200 mb-1">{label}{props.required && '*'}</label>
        <select id={name} name={name} {...props} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all">
            <option value="">Select {label}</option>
            {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    </div>
);
const TextAreaField: React.FC<any> = ({ label, name, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-sky-200 mb-1">{label}</label>
        <textarea id={name} name={name} {...props} rows={3} className="w-full bg-slate-900/70 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all" />
    </div>
);