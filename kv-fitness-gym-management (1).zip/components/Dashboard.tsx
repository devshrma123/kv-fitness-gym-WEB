
import React from 'react';
import { ReportStats } from '../types';
import { formatCurrency } from '../utils/helpers';

interface DashboardProps {
  stats: ReportStats;
}

const StatCard: React.FC<{ title: string; value: string | number; colorClass: string }> = ({ title, value, colorClass }) => (
  <div className={`bg-slate-800/50 border ${colorClass} rounded-2xl p-6 backdrop-blur-sm hover:bg-slate-700/50 hover:shadow-2xl hover:shadow-cyan-500/20 transition-all duration-300 transform hover:-translate-y-1`}>
    <h3 className="text-sm font-semibold uppercase tracking-wider text-sky-300">{title}</h3>
    <p className="text-3xl font-orbitron font-bold text-white mt-2">{value}</p>
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
      <StatCard title="Active Members" value={stats.activeMembers} colorClass="border-cyan-500/30" />
      <StatCard title="Expired Members" value={stats.expiredMembers} colorClass="border-rose-500/30" />
      <StatCard title="Gym Revenue (Total)" value={formatCurrency(stats.gymCollected)} colorClass="border-green-500/30" />
      <StatCard title="Gym Dues (Total)" value={formatCurrency(stats.gymDue)} colorClass="border-amber-500/30" />
    </div>
  );
};
