
import React, { useRef, useEffect, useCallback, useState } from 'react';

interface CameraModalProps {
  onCapture: (photo: string) => void;
  onClose: () => void;
}

export const CameraModal: React.FC<CameraModalProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera: ", err);
      setError("Could not access camera. Please check permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  }, []);
  
  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [startCamera, stopCamera]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const photoData = canvasRef.current.toDataURL('image/jpeg');
        onCapture(photoData);
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-slate-800/80 border border-cyan-500/20 rounded-2xl w-full max-w-2xl p-6 shadow-2xl shadow-cyan-900/50 relative" onClick={e => e.stopPropagation()}>
        <h2 className="text-2xl font-orbitron mb-4 text-center text-cyan-400">Take Photo</h2>
        {error ? (
            <p className="text-red-400 text-center">{error}</p>
        ) : (
            <video ref={videoRef} autoPlay playsInline className="w-full h-auto rounded-lg border-2 border-slate-600"></video>
        )}
        <canvas ref={canvasRef} className="hidden"></canvas>
        <div className="mt-6 flex justify-center gap-4">
            <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg transition-colors">Cancel</button>
            <button onClick={handleCapture} disabled={!!error} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-6 rounded-lg transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed">Capture</button>
        </div>
      </div>
    </div>
  );
};
