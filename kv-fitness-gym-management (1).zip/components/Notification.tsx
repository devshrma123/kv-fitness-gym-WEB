
import React, { useEffect, useState } from 'react';

export type NotificationType = 'success' | 'error';

interface NotificationProps {
  message: string;
  type: NotificationType;
  onClose: () => void;
}

export const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = setTimeout(() => {
      setVisible(false);
      // Allow time for fade-out animation before calling onClose
      setTimeout(onClose, 300);
    }, 2700);

    return () => clearTimeout(timer);
  }, [message, type, onClose]);
  
  const baseClasses = "fixed top-5 right-5 z-50 px-6 py-3 rounded-lg text-white font-bold shadow-2xl transition-all duration-300 transform";
  const typeClasses = type === 'success' 
    ? "bg-gradient-to-r from-green-500 to-cyan-600"
    : "bg-gradient-to-r from-red-500 to-orange-600";
  const visibilityClasses = visible ? "translate-x-0 opacity-100" : "translate-x-full opacity-0";

  return (
    <div className={`${baseClasses} ${typeClasses} ${visibilityClasses}`}>
      {message}
    </div>
  );
};
