
import { MembershipPlan } from '../types';

export const calculateEndDate = (startDate: string, plan: MembershipPlan): string => {
  if (!startDate || !plan) return '';

  const start = new Date(startDate);
  let endDate = new Date(start);

  switch (plan) {
    case MembershipPlan.FifteenDays:
      endDate.setDate(endDate.getDate() + 15);
      break;
    case MembershipPlan.OneMonth:
      endDate.setMonth(endDate.getMonth() + 1);
      break;
    case MembershipPlan.TwoMonths:
      endDate.setMonth(endDate.getMonth() + 2);
      break;
    case MembershipPlan.ThreeMonths:
      endDate.setMonth(endDate.getMonth() + 3);
      break;
    case MembershipPlan.SixMonths:
      endDate.setMonth(endDate.getMonth() + 6);
      break;
    case MembershipPlan.OneYear:
      endDate.setFullYear(endDate.getFullYear() + 1);
      break;
    default:
      return '';
  }

  return endDate.toISOString().split('T')[0];
};

export const formatCurrency = (amount: number): string => {
  return `₹${(amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const formatDate = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-GB'); // dd/mm/yyyy
};

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
};
